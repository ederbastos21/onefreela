> Sistema de Irrigação, utilizando:
```bash
Java
Java Swing
JPA/Hibernate
Maven
MySQL
```

> *Requer Maven e MySQL com user irrigation e senha 1843 como default para db_irrigation do projeto (pode ser alterado nas configurações de persistência do JPA no source!)

> Rodando em sistema Linux com ambiente Wayland puro (WM):
`env _JAVA_AWT_WM_NONREPARENTING=1 GDK_BACKEND=x11 mvn exec:java -Dexec.mainClass="br.com.sistema.irriga.view.MainFrame"`

> Sistemas com ambiente Xorg (sem parâmetros env):
`mvn exec:java -Dexec.mainClass="br.com.sistema.irriga.view.MainFrame"`

> Equipe:
`Amauri B. S. Junior, Eder de Bastos, Gustavo Bayer, Gabriel Lazarine, Carlos Aplewicz`