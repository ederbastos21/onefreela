package br.com.sistema.irriga.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "irrigations")
public class Irrigation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Temporal(TemporalType.DATE)
    private Date dataIrrigacao;
    private double quantidadeAgua;
    private String status;

    public Irrigation() {}

    public void agendar() { this.status = "Agendado"; }
    public void cancelar() { this.status = "Cancelado"; }
    public void concluir() { this.status = "Concluído"; }

    public void exibirAgendamento() {
        System.out.println("Irrigação: " + status + " Quantidade: " + quantidadeAgua);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Date getDataIrrigacao() { return dataIrrigacao; }
    public void setDataIrrigacao(Date dataIrrigacao) { this.dataIrrigacao = dataIrrigacao; }
    public double getQuantidadeAgua() { return quantidadeAgua; }
    public void setQuantidadeAgua(double quantidadeAgua) { this.quantidadeAgua = quantidadeAgua; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}