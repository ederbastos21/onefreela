package br.com.sistema.irriga.model;

import javax.persistence.*;

@Entity
@Table(name = "simulations")
public class SoilPlantAtmosphere {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.ALL)
    private Plant planta;

    @ManyToOne(cascade = CascadeType.ALL)
    private Weather clima;

    @ManyToOne(cascade = CascadeType.ALL)
    private SoilProfile solo;

    @ManyToOne(cascade = CascadeType.ALL)
    private GroundWater aguaSubterranea;

    public SoilPlantAtmosphere() {}

    public double calcularBalancoHidrico() {
        if (clima == null) return 0.0;
        return clima.getPrecipitacao() - calcularEvapotranspiracaoReal();
    }

    public double calcularEvapotranspiracaoReal() {
        if (clima == null) return 0.0;
        return clima.calcularEvapotranspiracao() * 0.8;
    }

    public boolean verificarNecessidadeIrrigacao() {
        return calcularBalancoHidrico() < 0.0;
    }

    public void gerarRelatorio() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Plant getPlanta() { return planta; }
    public void setPlanta(Plant planta) { this.planta = planta; }
    public Weather getClima() { return clima; }
    public void setClima(Weather clima) { this.clima = clima; }
    public SoilProfile getSolo() { return solo; }
    public void setSolo(SoilProfile solo) { this.solo = solo; }
    public GroundWater getAguaSubterranea() { return aguaSubterranea; }
    public void setAguaSubterranea(GroundWater aguaSubterranea) { this.aguaSubterranea = aguaSubterranea; }
}