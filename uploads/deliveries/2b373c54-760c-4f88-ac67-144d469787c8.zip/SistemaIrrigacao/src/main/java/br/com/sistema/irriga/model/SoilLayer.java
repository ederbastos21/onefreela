package br.com.sistema.irriga.model;

import javax.persistence.*;

@Entity
@Table(name = "soil_layers")
public class SoilLayer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private int profundidade;
    private double umidadeAtual;
    private double capacidadeRetencao;
    private double infiltracao;

    public SoilLayer() {}

    public void atualizarUmidade() {
        this.umidadeAtual += (this.infiltracao * 0.1);
    }

    public double calcularDrenagem() {
        return this.umidadeAtual > this.capacidadeRetencao ? (this.umidadeAtual - this.capacidadeRetencao) : 0.0;
    }

    public double calcularInfiltracao() {
        return this.infiltracao * 0.9;
    }

    public void exibirCamada() {
        System.out.println("Camada prof: " + profundidade + " - Umidade: " + umidadeAtual);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getProfundidade() { return profundidade; }
    public void setProfundidade(int profundidade) { this.profundidade = profundidade; }
    public double getUmidadeAtual() { return umidadeAtual; }
    public void setUmidadeAtual(double umidadeAtual) { this.umidadeAtual = umidadeAtual; }
    public double getCapacidadeRetencao() { return capacidadeRetencao; }
    public void setCapacidadeRetencao(double capacidadeRetencao) { this.capacidadeRetencao = capacidadeRetencao; }
    public double getInfiltracao() { return infiltracao; }
    public void setInfiltracao(double infiltracao) { this.infiltracao = infiltracao; }
}