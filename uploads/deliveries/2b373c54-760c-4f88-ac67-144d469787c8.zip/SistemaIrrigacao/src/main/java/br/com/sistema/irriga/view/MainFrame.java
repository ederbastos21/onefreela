package br.com.sistema.irriga.view;

import br.com.sistema.irriga.model.Plant;
import br.com.sistema.irriga.repository.GenericDAO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {
    private final GenericDAO<Plant> plantDAO = new GenericDAO<>(Plant.class);

    private JTextField txtNome = new JTextField(15);
    private JTextField txtTipo = new JTextField(15);
    private JTextField txtCoeficiente = new JTextField(5);
    private JTextField txtProfundidade = new JTextField(5);
    private JTextField txtNecessidade = new JTextField(5);

    private JButton btnSalvar = new JButton("Salvar Planta");
    private JButton btnExcluir = new JButton("Excluir Selecionada");
    private JTable tabelaPlantas;
    private DefaultTableModel modeloTabela;

    public MainFrame() {
        setTitle("Sistema Integrador de Irrigação");
        setSize(850, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Formulário de Cadastro"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; painelFormulario.add(new JLabel("Nome da Planta:"), gbc);
        gbc.gridx = 1; painelFormulario.add(txtNome, gbc);

        gbc.gridx = 0; gbc.gridy = 1; painelFormulario.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1; painelFormulario.add(txtTipo, gbc);

        gbc.gridx = 2; gbc.gridy = 0; painelFormulario.add(new JLabel("Coef. Cultura (Kc):"), gbc);
        gbc.gridx = 3; painelFormulario.add(txtCoeficiente, gbc);

        gbc.gridx = 2; gbc.gridy = 1; painelFormulario.add(new JLabel("Profundidade Raiz:"), gbc);
        gbc.gridx = 3; painelFormulario.add(txtProfundidade, gbc);

        gbc.gridx = 0; gbc.gridy = 2; painelFormulario.add(new JLabel("Necessidade Hídrica:"), gbc);
        gbc.gridx = 1; painelFormulario.add(txtNecessidade, gbc);

        gbc.gridx = 2; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(btnSalvar, gbc);

        add(painelFormulario, BorderLayout.NORTH);

        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Tipo", "Coef. Cultura", "Prof. Raiz", "Nec. Hídrica"}, 0);
        tabelaPlantas = new JTable(modeloTabela);
        JScrollPane painelRolagem = new JScrollPane(tabelaPlantas);
        painelRolagem.setBorder(BorderFactory.createTitledBorder("Tabela Sincronizada com Banco de Dados MySQL"));
        add(painelRolagem, BorderLayout.CENTER);

        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        painelAcoes.add(btnExcluir);
        add(painelAcoes, BorderLayout.SOUTH);

        btnSalvar.addActionListener(e -> salvarPlanta());
        btnExcluir.addActionListener(e -> excluirPlanta());

        carregarDadosTabela();
    }

    private void salvarPlanta() {
        try {
            Plant planta = new Plant();
            planta.setNome(txtNome.getText());
            planta.setTipo(txtTipo.getText());
            planta.setCoeficienteCultura(Double.parseDouble(txtCoeficiente.getText()));
            planta.setProfundidadeRaiz(Double.parseDouble(txtProfundidade.getText()));
            planta.setNecessidadeHidrica(Double.parseDouble(txtNecessidade.getText()));

            plantDAO.save(planta);
            JOptionPane.showMessageDialog(this, "Planta gravada no MySQL com sucesso!");
            limparCampos();
            carregarDadosTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro. Certifique-se de preencher valores numéricos válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirPlanta() {
        int linhaSelecionada = tabelaPlantas.getSelectedRow();
        if (linhaSelecionada >= 0) {
            int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
            plantDAO.delete(id);
            JOptionPane.showMessageDialog(this, "Registro excluído permanentemente do banco.");
            carregarDadosTabela();
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecione uma linha para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void carregarDadosTabela() {
        modeloTabela.setRowCount(0);
        try {
            List<Plant> plantas = plantDAO.findAll();
            for (Plant p : plantas) {
                modeloTabela.addRow(new Object[]{p.getId(), p.getNome(), p.getTipo(), p.getCoeficienteCultura(), p.getProfundidadeRaiz(), p.getNecessidadeHidrica()});
            }
        } catch (Exception e) {
            System.out.println("Banco de dados iniciando ou vazio. Conexão OK.");
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtTipo.setText("");
        txtCoeficiente.setText("");
        txtProfundidade.setText("");
        txtNecessidade.setText("");
    }

    private static void setUIFont() {
        Font font = new Font("Noto Sans", Font.PLAIN, 14);

        UIManager.put("Label.font", font);
        UIManager.put("Button.font", font);
        UIManager.put("TextField.font", font);
        UIManager.put("Table.font", font);
        UIManager.put("TableHeader.font", font);
    }

    public static void main(String[] args) {
        setUIFont();

        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}