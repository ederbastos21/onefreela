package br.com.sistema.irriga.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "weather_records")
public class Weather {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private double temperatura;
    private double umidade;
    private double precipitacao;
    private double velocidadeVento;

    @Temporal(TemporalType.DATE)
    private Date dataRegistro;

    public Weather() {}

    public void registrarDados() {
        this.dataRegistro = new Date();
    }

    public void atualizarDados() {}

    public double calcularEvapotranspiracao() {
        return (this.temperatura * 0.1) + (this.velocidadeVento * 0.2);
    }

    public void exibirDados() {
        System.out.println("Clima - Temp: " + temperatura + "°C");
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public double getTemperatura() { return temperatura; }
    public void setTemperatura(double temperatura) { this.temperatura = temperatura; }
    public double getUmidade() { return umidade; }
    public void setUmidade(double umidade) { this.umidade = umidade; }
    public double getPrecipitacao() { return precipitacao; }
    public void setPrecipitacao(double precipitacao) { this.precipitacao = precipitacao; }
    public double getVelocidadeVento() { return velocidadeVento; }
    public void setVelocidadeVento(double velocidadeVento) { this.velocidadeVento = velocidadeVento; }
    public Date getDataRegistro() { return dataRegistro; }
    public void setDataRegistro(Date dataRegistro) { this.dataRegistro = dataRegistro; }
}