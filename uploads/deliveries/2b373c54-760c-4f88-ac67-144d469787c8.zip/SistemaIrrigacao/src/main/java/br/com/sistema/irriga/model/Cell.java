package br.com.sistema.irriga.model;

import javax.persistence.*;

@Entity
@Table(name = "cells")
public class Cell {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(cascade = CascadeType.ALL)
    private SoilProfile solo;

    @ManyToOne(cascade = CascadeType.ALL)
    private Plant planta;

    @ManyToOne(cascade = CascadeType.ALL)
    private Weather clima;

    public Cell() {}

    public void iniciarSimulacao() {}
    public void atualizarEstado() {}
    public void exibirStatus() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public SoilProfile getSolo() { return solo; }
    public void setSolo(SoilProfile solo) { this.solo = solo; }
    public Plant getPlanta() { return planta; }
    public void setPlanta(Plant planta) { this.planta = planta; }
    public Weather getClima() { return clima; }
    public void setClima(Weather clima) { this.clima = clima; }
}