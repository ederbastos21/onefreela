package br.com.sistema.irriga.model;

import javax.persistence.*;

@Entity
@Table(name = "plants")
public class Plant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private String nome;
    private String tipo;
    private double coeficienteCultura;
    private double profundidadeRaiz;
    private double necessidadeHidrica;

    public Plant() {}

    public void cadastrar() {}
    public void atualizar() {}
    public void remover() {}

    public void exibirInformacoes() {
        System.out.println("Planta: " + nome + " (" + tipo + ")");
    }

    public double calcularConsumoAgua() {
        return this.necessidadeHidrica * this.coeficienteCultura;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public double getCoeficienteCultura() { return coeficienteCultura; }
    public void setCoeficienteCultura(double coeficienteCultura) { this.coeficienteCultura = coeficienteCultura; }
    public double getProfundidadeRaiz() { return profundidadeRaiz; }
    public void setProfundidadeRaiz(double profundidadeRaiz) { this.profundidadeRaiz = profundidadeRaiz; }
    public double getNecessidadeHidrica() { return necessidadeHidrica; }
    public void setNecessidadeHidrica(double necessidadeHidrica) { this.necessidadeHidrica = necessidadeHidrica; }
}