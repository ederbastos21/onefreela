package br.com.sistema.irriga.model;

import javax.persistence.*;

@Entity
@Table(name = "groundwaters")
public class GroundWater {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private double profundidade;
    private double nivelAgua;

    public GroundWater() {}

    public void atualizarNivel() { this.nivelAgua += 0.01; }
    public double calcularDisponibilidadeAgua() { return this.nivelAgua * 75.0; }
    
    public void exibirDados() {
        System.out.println("Lençol Freático Nível: " + nivelAgua);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public double getProfundidade() { return profundidade; }
    public void setProfundidade(double profundidade) { this.profundidade = profundidade; }
    public double getNivelAgua() { return nivelAgua; }
    public void setNivelAgua(double nivelAgua) { this.nivelAgua = nivelAgua; }
}