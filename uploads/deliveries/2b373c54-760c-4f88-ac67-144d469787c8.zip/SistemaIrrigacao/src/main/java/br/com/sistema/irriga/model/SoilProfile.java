package br.com.sistema.irriga.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "soil_profiles")
public class SoilProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private String tipoSolo;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "soil_profile_id")
    private List<SoilLayer> camadas = new ArrayList<>();

    public SoilProfile() {}

    public void adicionarCamada() {}
    public void removerCamada() {}

    public double calcularUmidadeTotal() {
        return camadas.stream().mapToDouble(SoilLayer::getUmidadeAtual).sum();
    }

    public void exibirPerfil() {
        System.out.println("Perfil do Solo: " + tipoSolo);
    }

    public void addCamada(SoilLayer camada) { this.camadas.add(camada); }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTipoSolo() { return tipoSolo; }
    public void setTipoSolo(String tipoSolo) { this.tipoSolo = tipoSolo; }
    public List<SoilLayer> getCamadas() { return camadas; }
    public void setCamadas(List<SoilLayer> camadas) { this.camadas = camadas; }
}